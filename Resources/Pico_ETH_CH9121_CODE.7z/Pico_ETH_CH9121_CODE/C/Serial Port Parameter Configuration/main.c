﻿#include "CH9121_Test.h"

int main()
{
    Pico_ETH_CH9121_test();
}
